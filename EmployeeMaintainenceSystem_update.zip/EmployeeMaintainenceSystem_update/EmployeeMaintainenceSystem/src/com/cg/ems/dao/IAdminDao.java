package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.dto.AdminBean;
import com.cg.ems.exception.AdminException;

public interface IAdminDao {
	public String add(AdminBean admin) throws AdminException;
	 List<AdminBean> showAll() throws AdminException;
	 void update(AdminBean e)throws AdminException;
		AdminBean search(String empid)throws AdminException;
}
