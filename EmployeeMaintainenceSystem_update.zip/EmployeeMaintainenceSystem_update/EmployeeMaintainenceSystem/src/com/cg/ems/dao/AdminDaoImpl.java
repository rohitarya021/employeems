package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.ems.dto.AdminBean;
import com.cg.ems.exception.AdminException;
import com.cg.ems.util.DBUtil;





public class AdminDaoImpl implements IAdminDao{
	private static final String INSERT_QUERY="Insert into employee values(emp_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String GET_ALL_QUERY="select * from employee";
	private static final String UPDATE_QUERY="update employee set first_name=?,last_name=?,date_birth=?,date_joining=?,dept_id=?,grade=?,designation=?,basic_pay=?,gender=?,marital_status=?,home_address=?,contact_num=? where emp_id=?";
	private static final String SELECT_QUERY="select emp_id,first_name,last_name,date_birth,date_joining,dept_id,"
			 +"grade,designation,basic_pay,gender,marital_status,home_address,contact_num from employee where emp_id=?";
	
	Connection con=null;
	PreparedStatement ps=null;

	@Override
	public String add(AdminBean admin) throws AdminException {
		
		try {
			con=DBUtil.getConnection();
			ps=con.prepareStatement(INSERT_QUERY);
			ps.setString(1,admin.getFirst_name());
			ps.setString(2, admin.getLast_name());
			ps.setDate(3, admin.getDate_birth());
			ps.setDate(4, admin.getDate_joining() );
			ps.setInt(5, admin.getDept_id());
			ps.setString(6, admin.getGrade());
			ps.setString(7, admin.getDesignation());
			ps.setInt(8, admin.getBasic_pay());
			ps.setString(9, admin.getGender());
			ps.setString(10, admin.getMarital_status());
			ps.setString(11, admin.getHome_address());
			ps.setString(12, admin.getContact_num());
			
			ps.executeUpdate();
			String id="0";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select emp_seq.currval from dual");
			if(rs.next()){
				id=rs.getString(1);
			}
			con.close();
			return id;
			
		}
			catch (SQLException | NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new AdminException("unable to insert data" +e.getMessage());
			}
		
	
		
		
		
		
		
	}

	@Override
	public List<AdminBean> showAll() throws AdminException {
		try {
			con=DBUtil.getConnection();
			ps=con.prepareStatement(GET_ALL_QUERY);
			ResultSet rs=ps.executeQuery();
			List<AdminBean> admin=new LinkedList<>();
			while(rs.next()){
				AdminBean ad=new AdminBean();
				ad.setEmp_id(rs.getString(1));
				ad.setFirst_name(rs.getString(2));
				ad.setLast_name(rs.getString(3));
				ad.setDate_birth(rs.getDate(4));
				ad.setDate_joining(rs.getDate(5));
				ad.setDept_id(rs.getInt(6));
				ad.setGrade(rs.getString(7));
				ad.setDesignation(rs.getString(8));
				ad.setBasic_pay(rs.getInt(9));
				ad.setGender(rs.getString(10));
				ad.setMarital_status(rs.getString(11));
				ad.setHome_address(rs.getString(12));
				ad.setContact_num(rs.getString(13));
				admin.add(ad);
				
				
			}
			con.close();
			return admin;
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AdminException("unable to fetch records" +e.getMessage());
		} 
		
		
	}

	@Override
	public void update(AdminBean e) throws AdminException {
	
		try {
			
			con=DBUtil.getConnection();
			 ps = con.prepareStatement(UPDATE_QUERY);
			 ps.setString(1,e.getFirst_name());
			 ps.setString(2,e.getLast_name());
			 ps.setDate(3, e.getDate_birth());
			 ps.setDate(4,e.getDate_joining());
			 ps.setInt(5,e.getDept_id());
			 ps.setString(6,e.getGrade());
			 ps.setString(7,e.getDesignation());
			 ps.setInt(8,e.getBasic_pay());
			 ps.setString(9,e.getGender());
			 ps.setString(10,e.getMarital_status());
			 ps.setString(11,e.getHome_address());
			 ps.setString(12,e.getContact_num());
			 ps.setString(13,e.getEmp_id());
				ps.executeUpdate();
				System.out.println("yahan aa gya");
				System.out.println(e);	
				con.close();
			 
		} catch (NamingException  | SQLException e1) {
			
			e1.printStackTrace();
			throw new AdminException("Unable to save, "+e1.getMessage());
		} 
		
	}

	@Override
	public AdminBean search(String empid) throws AdminException {
		try {
			con = DBUtil.getConnection();
			ps = con.prepareStatement(SELECT_QUERY);
			
ps.setString(1, empid);
			
			ResultSet rs = ps.executeQuery();
			AdminBean a = new AdminBean();
			if(rs.next()){
			
				a.setEmp_id(rs.getString(1));
				a.setFirst_name(rs.getString(2));
				a.setLast_name(rs.getString(3));
				a.setDate_birth(rs.getDate(4));
				a.setDate_joining(rs.getDate(5));
				a.setDept_id(rs.getInt(6));
				a.setGrade(rs.getString(7));
				a.setDesignation(rs.getString(8));
				a.setBasic_pay(rs.getInt(9));
				a.setGender(rs.getString(10));
				a.setMarital_status(rs.getString(11));
				a.setHome_address(rs.getString(12));
				a.setContact_num(rs.getString(13));
				
			}
			con.close();
			return a; 
			
			
		} catch (NamingException |SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new AdminException("Unable to fetch records, "+e.getMessage());
		}
		
	}

}
