package com.cg.ems.service;

import java.util.List;

import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.IAdminDao;
import com.cg.ems.dto.AdminBean;
import com.cg.ems.exception.AdminException;

public class AdminServiceImpl implements IAdminService{
	IAdminDao dao = new AdminDaoImpl();

	@Override
	public String add(AdminBean admin) throws AdminException {
		
		return dao.add(admin);
	}

	@Override
	public List<AdminBean> showAll() throws AdminException {
		
		return dao.showAll();
	}

	@Override
	public void update(AdminBean e) throws AdminException {
		dao.update(e);
	}

	@Override
	public AdminBean search(String empid) throws AdminException {
		
		return dao.search(empid);
	}

}
