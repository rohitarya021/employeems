package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Mobile> showAll() {
	
		Query queryOne=entityManager.createQuery("FROM Mobile");
		List<Mobile> allData=queryOne.getResultList();
		return allData;
	}

	@Override
	public void removeMobile(int mobileId) {
		
		// TODO Auto-generated method stub
		
		Query queryTwo=entityManager.createQuery("DELETE FROM Mobile WHERE mobileId=:mob_id");//java ,sql schema
		
		queryTwo.setParameter("mob_id",mobileId);
		queryTwo.executeUpdate();
		
	}

	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}

}
