package com.cg.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCTDATA")
public class Product
{ 
  
  @Id	
  @Column(name="prod_id")
  private Integer productID;   //making productID as primary key because of @Id
  
   @Column(name="prod_name")
  private String productName;
  
  @Column(name="prod_type")
  private String productType;
  
  @Column(name="prod_price")
  private double productPrice;
  
  @Column(name="prod_online")
  private String productOnline;

  public Integer getProductID() {
	return productID;
}
public void setProductID(Integer productID) {
	this.productID = productID;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getProductType() {
	return productType;
}
public void setProductType(String productType) {
	this.productType = productType;
}
public double getProductPrice() {
	return productPrice;
}
public void setProductPrice(double productPrice) {
	this.productPrice = productPrice;
}
public String getProductOnline() {
	return productOnline;
}
public void setProductOnline(String productOnline) {
	this.productOnline = productOnline;
}
@Override
public String toString() {
	return "Product [productID=" + productID + ", productName=" + productName
			+ ", productType=" + productType + ", productPrice=" + productPrice
			+ ", productOnline=" + productOnline + "]";
}
  
}
