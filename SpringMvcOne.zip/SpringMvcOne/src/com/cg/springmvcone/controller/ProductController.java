package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Product;
import com.cg.springmvcone.service.IProductService;



@Controller
public class ProductController

{
     @Autowired
	IProductService productservice;
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Product pro, Map<String,Object> model){
		
		List<String> myList=new ArrayList<String>();
		
		myList.add("Electronics");
		myList.add("Grocery");
		myList.add("Home-Appliances");
		
		model.put("ptype", myList);
		
		return "addProduct" ;       //sends to welcome.jsp page
		}

@RequestMapping(value="putdata",method=RequestMethod.POST)
public String dataAdd(@ModelAttribute("my") Product pro){

	
	productservice.insertData(pro);
	return null;
	
}


@RequestMapping(value="showall",method=RequestMethod.GET)
public ModelAndView dataShow()
{
	
	List<Product> allData=productservice.showData();
	return new ModelAndView("prodshow","mydata",allData);//jsp page,temporary variable,main
	}


@RequestMapping(value="search",method=RequestMethod.GET)
public String searchPage(@ModelAttribute("data") Product pSearch)
{
	return "prodsearch";
	
}
@RequestMapping(value="searchdata",method=RequestMethod.POST)
public ModelAndView searchData(@ModelAttribute Product pData)
{
int prodId=pData.getProductID();
List<Product> searchData=productservice.searchData(prodId);

return new ModelAndView("prodshow","mydata",searchData);
		
}

public void removeData(@ModelAttribute Product pData)
{
	int prodId=pData.getProductID();
	productservice.removeData(prodId);
	

}







}
