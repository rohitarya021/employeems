package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Product;

@Repository("productdao")
public class ProductDaoImpl implements IProductDao
{
    
	@PersistenceContext
	EntityManager entityManager;    //coming from dispatcher servlet.xml
	
	@Override
	public void insertData(Product prod) {
		// TODO Auto-generated method stub
		
	entityManager.persist(prod);	
	entityManager.flush();
		
	}

	@Override
	public List<Product> showData() {
		// TODO Auto-generated method stub
		Query queryOne=entityManager.createQuery("FROM Product"); //CLASSNAME NOT TABLENAME
		List<Product> dataList=queryOne.getResultList();
		return dataList;
	}

	@Override
	public void removeData(int prodId) {
		// TODO Auto-generated method stub
		Query queryThree=entityManager.createQuery("DELETE FROM Product WHERE productID=:prod_id");//java then sql
		queryThree.setParameter("prod_id", prodId);	//sql and java	
		
	
		
	}

	@Override
	public List<Product> searchData(int prodId) {
		// TODO Auto-generated method stub
		
		Query queryTwo=entityManager.createQuery("FROM Product WHERE productID=:prod_id");//java then sql
		queryTwo.setParameter("prod_id", prodId);	//sql and java	
		List<Product> mySearch=queryTwo.getResultList();
		
		return mySearch;
	}

}
