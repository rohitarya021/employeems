package com.cg.springmvcone.dao;

import java.util.List;

import com.cg.springmvcone.dto.Product;

public interface IProductDao
{
	public void insertData(Product prod);
	public List<Product> showData();
	public void removeData(int prodId);
	public List<Product> searchData(int prodId);
}
