package com.cg.springmvcone.service;

import java.util.List;

import com.cg.springmvcone.dto.Product;

public interface IProductService 
{
public void insertData(Product prod);
public List<Product> showData();
public void removeData(int prodId);
public List<Product> searchData(int prodId);

}
