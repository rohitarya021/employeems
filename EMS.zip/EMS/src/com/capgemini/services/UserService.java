package com.capgemini.services;

import com.capgemini.entities.User;

public interface UserService {
	
	User usrCheck(String usrName,String usrPass);

}
