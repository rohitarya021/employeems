package com.capgemini.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.daos.EmployeeDao;
import com.capgemini.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public List<Employee> getAllEmployee() {
		
		return empDao.getAllEmployee();
	}
	@Override
	public void addEmployee(Employee emp) {
		
		empDao.addEmployee(emp);
	}
	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		return empDao.getEmployeeById(id);
	}
	@Override
	public void updateEmployee(Employee emp) {
		empDao.updateEmployee(emp);
		
	}

}
