package com.capgemini.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entities.User;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public User usrCheck(String usrName, String usrPass) {
		
		TypedQuery<User> queryForUserCheck = entitymanager.createQuery("SELECT u FROM User u WHERE u.userName = '"+usrName+"' "
				+ "AND u.userPassword = '"+usrPass+"' " ,User.class);
		//queryForUserCheck.setParameter("usrName", usrName);
		//queryForUserCheck.setParameter("usrPass", usrPass);
		User user = (User) queryForUserCheck.getSingleResult();
	
	return user;	
	}

}
