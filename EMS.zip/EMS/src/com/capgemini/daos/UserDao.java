package com.capgemini.daos;

import com.capgemini.entities.User;

public interface UserDao {
	
	User usrCheck(String usrName,String usrPass);

}
