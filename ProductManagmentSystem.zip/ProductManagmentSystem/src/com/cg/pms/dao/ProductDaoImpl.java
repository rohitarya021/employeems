package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;
import com.cg.pms.util.DbUtil;

public class ProductDaoImpl implements IProductDao{
private static final Logger myLog=Logger.getLogger(ProductDaoImpl.class);	
	
static Connection con=null;
static PreparedStatement pstm=null;
	@Override
	public int addProduct(Product pro) throws ProductException {
		int status=0;
		int idReturn=0;
		// TODO Auto-generated method stub
		con=DbUtil.getConnection();
		int prodId=getProductId();
		String query="INSERT INTO PRODUCTDB VALUES(?,?,?,?)";
		try {
			pstm=con.prepareStatement(query);
			pstm.setInt(1,prodId);
			pstm.setString(2,pro.getProductName());
			pstm.setDouble(3,pro.getProductPrice());
			pstm.setString(4,pro.getProductDes());
			
			 status=pstm.executeUpdate();
			 if(status==1){
				 idReturn=prodId;
	myLog.info("Data Inserted.."+prodId);			 
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductException(" Problem In Insert..");
		}
		finally{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//myLog.info(i);
		return idReturn;
	}

	@Override
	public List<Product> showall() throws ProductException {
		// TODO Auto-generated method stub
		System.out.println(" In Dao....");
		List<Product> myList=new ArrayList<Product>();
		con=DbUtil.getConnection();
		String queryTwo=
"SELECT prod_id,prod_name,prod_price,prod_des FROM PRODUCTDB";
try {
	pstm=con.prepareStatement(queryTwo);
	ResultSet res=pstm.executeQuery();
	while(res.next()){
		Product pr=new Product();
		pr.setProductId(res.getInt("prod_id"));
		pr.setProductName(res.getString("prod_name"));
		pr.setProductPrice(res.getDouble("prod_price"));
		pr.setProductDes(res.getString("prod_des"));
		
		myList.add(pr);
		//System.out.println(myList);
	}
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	throw new ProductException("Problem in Show..");
}finally{
	try {
		pstm.close();
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


		return myList;
	}

	@Override
	public Product searchProduct(int prodId) throws ProductException {
		// TODO Auto-generated method stub
		Product pSearch=null;
		try {
			con=DbUtil.getConnection();
String queryThree="SELECT prod_name,prod_price,prod_des FROM PRODUCTDB WHERE prod_id=?";			
pstm=con.prepareStatement(queryThree);
pstm.setInt(1,prodId);
ResultSet resOne=pstm.executeQuery();
while(resOne.next()){
	pSearch=new Product();
	pSearch.setProductName(resOne.getString("prod_name"));
	pSearch.setProductPrice(resOne.getDouble("prod_price"));
	pSearch.setProductDes(resOne.getString("prod_des"));
}

		} catch (ProductException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductException(" Problem in serach..");
		}
		finally{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return pSearch;
	}

	@Override
	public void removeProduct(int prodId) {
		// TODO Auto-generated method stub
		
	}
	
	public static int getProductId() throws ProductException{
		int productId=0;
		try {
			con=DbUtil.getConnection();
String queryFive="SELECT prod_id_seq.nextval FROM DUAL";
pstm=con.prepareStatement(queryFive);
ResultSet resTwo=pstm.executeQuery();
while(resTwo.next()){
	productId=resTwo.getInt(1);
}
		} catch (ProductException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ProductException("Problem in Getting Id");
		}
		return productId;
		
	}

}
