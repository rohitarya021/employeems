package com.cg.pms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;
import com.cg.pms.service.IProductService;
import com.cg.pms.service.ProductServiceImpl;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int choice=0;
//Run Time polymorphism
IProductService prodservice=new ProductServiceImpl();

do{
	printDetail();
	
	Scanner scr=new Scanner(System.in);
	System.out.println("Enter the choice..");
	choice=scr.nextInt();
	
	switch(choice){
	
	case 1://Add
		int msg=0;
		//System.out.println("Enter the Product Id");
		//int prodId=scr.nextInt();
		String patt="[A-Z][a-z]{2,19}";
		System.out.println("Enter the Product Name");
		String prodName=scr.next();
		try {
			ProductServiceImpl.validateName(prodName, patt);
		} catch (ProductException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			System.out.println(e1.getMessage());
			break;
		}
		System.out.println("Enter the Price ");
		double prodPrice=scr.nextDouble();
		System.out.println("Enter the description ");
		String prodDes=scr.next();
		
		Product prod=new Product();
		//prod.setProductId(prodId);
		prod.setProductName(prodName);
		prod.setProductPrice(prodPrice);
		prod.setProductDes(prodDes);
		//calling service layer..
		
		try {
			msg = prodservice.addProduct(prod);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		if(msg==0){
			System.out.println("Data not Inserted");
		}else{
			System.out.println("Data Inserted Product Id is "+msg);
		}
		break;
		
		
	case 2://showAll
		List<Product> myProd=null;
		try {
			myProd = prodservice.showall();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		for (Product product : myProd) {
			System.out.println(" Id is "+product.getProductId());
			System.out.println(" Name is "+product.getProductName());
			System.out.println(" Price "+product.getProductPrice());
			System.out.println(" Description "+product.getProductDes());
		}
		break;
	case 3: //Serach
		System.out.println("Enter Product Id.");
		int id=scr.nextInt();
		Product mySearchProd=null;
		try {
			mySearchProd = prodservice.searchProduct(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		//System.out.println(" Id is "+mySearchProd.getProductId());
		System.out.println(" Name is "+mySearchProd.getProductName());
		System.out.println(" Price "+mySearchProd.getProductPrice());
		System.out.println(" Description "+mySearchProd.getProductDes());
		
		break;
	case 4: //Remove
		
		break;
	case 5://Exit
		System.exit(0);
		break;
	}
	
}while(choice!=5);
	}
	
	public static void printDetail(){
		
		System.out.println("*************");
		System.out.println("1. ADD Product");
		System.out.println("2 .Show All Product");
		System.out.println("3. Serach Product");
		System.out.println("4. Remove Product");
		System.out.println("5. Exit");
		System.out.println("**************");
		
	}

}
