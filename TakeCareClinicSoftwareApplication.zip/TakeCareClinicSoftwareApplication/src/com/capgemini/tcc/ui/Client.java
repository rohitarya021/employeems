package com.capgemini.tcc.ui;

import java.sql.SQLException;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;


public class Client {

	public static void main(String[] args) throws PatientException, SQLException {
		// TODO Auto-generated method stub

		int choice=0;
		
		IPatientService patientservice=new PatientService();
		
		
		do{ 
			
		
		printDetail();
		
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter the choice..");
		choice=scr.nextInt();
		
		switch(choice)
		{
		
		case 1:  //add
			String patt="[A-Z][a-z]{2,19}";
		System.out.println("Enter the name of the Patient");
		String patientName=scr.next();
		try {
			boolean bool = PatientService.validateName(patientName, patt);
			if (!bool)
			{
				System.out.println("First Letter should be capital min3 max20");
			}
			
			
			
			
		} catch (PatientException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			System.out.println(e1.getMessage());
			
		}
		System.out.println("Enter Patient Age");
		int patientAge=scr.nextInt();
		
		
		System.out.println("Enter Patient Phone Number");
		double patientPhone=scr.nextDouble();
		
		String patt1="[A-Z][a-z]{2,19}";
		System.out.println("Enter Description");
		String patientDesc=scr.next();
		try {
			boolean bool = PatientService.validateDescription(patientDesc, patt1);
			if (!bool)
			{
				System.out.println("First Letter should be capital min3 max20");
			}
			
			
			
			
		} catch (PatientException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			System.out.println(e1.getMessage());
			break;
		}
		
		
		PatientBean patient=new PatientBean();
		//prod.setProductId(prodId);
		patient.setPatientName(patientName);
		patient.setPatientAge(patientAge);
		patient.setPatientPhone(patientPhone);
		patient.setPatientDesc(patientDesc);
		//calling service layer..
		
		
		int patientId=0;
		
			try {
				
				
				
				 patientId = patientservice.addPatientDetails(patient);
			} catch (PatientException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new PatientException("Problem in adding data");
			}
		
		
			
			System.out.println("Patient Information stored successfully for "+ patientId);
			
			
		break;
		
		
		case 2://show
			
			PatientBean pt =null;
			
			
			System.out.println("enter the patient id");
			int patientid=scr.nextInt(); 
			
			pt = patientservice.getPatientDetails(patientid);
			  
			 
			  
					System.out.println(" Name of the Patient"+pt.getPatientName());
					System.out.println(" Age"+pt.getPatientAge());
					System.out.println(" Phone Number "+pt.getPatientPhone());
					System.out.println(" Description"+pt.getPatientDesc());
					System.out.println(" Consultation Date "+pt.getConsultationdate());
				
			
			
			break;
			  
			
			
		case 3://exit
			
			System.exit(0);
			break;
			
			
			
		}
		
		}while(choice!=3);
		
	   
	}	

	
	public static void printDetail()
	{
		System.out.println("=====================================================================");
		System.out.println("*********************************************************************");
		System.out.println("1.  Add Patient Information");
		System.out.println("2.  Search Patient by Id");
		System.out.println("3.  Exit");
	    System.out.println("*********************************************************************");
		System.out.println("=====================================================================");
	}
}
