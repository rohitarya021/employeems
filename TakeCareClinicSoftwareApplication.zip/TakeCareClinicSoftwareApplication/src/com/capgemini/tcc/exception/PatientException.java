package com.capgemini.tcc.exception;

public class PatientException extends Exception{

	public PatientException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
