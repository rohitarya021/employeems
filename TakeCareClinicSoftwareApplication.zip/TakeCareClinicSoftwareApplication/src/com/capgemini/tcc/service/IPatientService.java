package com.capgemini.tcc.service;

import java.sql.SQLException;
import java.util.List;



import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;


public interface IPatientService 
{
int addPatientDetails(PatientBean patient) throws PatientException;

PatientBean getPatientDetails (int patientId) throws PatientException;
	
	
	
	
	
}
