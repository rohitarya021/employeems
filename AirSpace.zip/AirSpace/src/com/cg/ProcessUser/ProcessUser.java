package com.cg.ProcessUser;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.CustomerException;
import com.cg.service.CustomerServiceImpl;
import com.cg.service.ICustomerService;
import com.cg.userbean.Customer;








/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("/controller")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ProcessUser() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		//Create instance of Service
		ICustomerService service = new CustomerServiceImpl();
		
		Customer user = new Customer();
		switch(action)
		{
		case "addUser":
			//code to add employee
			int status=0;
			user.setName(request.getParameter("name"));
			user.setPhone(request.getParameter("mobileno"));
			user.setUname(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			String Repassword=request.getParameter("repassword");
			if(Repassword.equals(request.getParameter("password")))
			{
			try {
				throw new CustomerException("Password and Re Enter Password does not match");
				} 
				catch (CustomerException e) 
				{
					e.printStackTrace();
				}
			}
			//save using service
			try{
			status=service.add(user);
			}
			catch(CustomerException ex)
			{
				request.getSession().setAttribute("error", ex.getMessage());	
			}
			if(status==1)
			{
				//store in SESSION
				request.getSession().setAttribute("user", user);
			}
			RequestDispatcher rd = request.getRequestDispatcher("CustomerHome.jsp");
			rd.forward(request, response);
			return;
		
		
		
		
		case "Register":
			//code to add employee
			Customer user1 = new Customer();
			user1.setName(request.getParameter("name"));
			user1.setPhone(request.getParameter("uname"));
			user1.setUname(request.getParameter("password"));
			user1.setPassword(request.getParameter("repassword"));
			user1.setRepassword(request.getParameter("mobile"));
			
			//save using service
			String name = service.register(user);
			user.setUname(name);
			//store error/success message in SESSION
			request.getSession().setAttribute("emp",user);
			//forward request to "success.jsp"
			RequestDispatcher view2 = request.getRequestDispatcher("success.jsp");
			view2.forward(request, response);
			
			
			return;
			
		
		
		
		
		
		
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
