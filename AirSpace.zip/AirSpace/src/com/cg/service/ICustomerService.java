package com.cg.service;

import java.util.List;



import com.cg.exception.CustomerException;


import com.cg.userbean.Customer;



public interface ICustomerService {

	

	int add(Customer e) throws CustomerException;
	
	List<Customer> getAll() throws CustomerException;

	String register(Customer user);
}
