package com.cg.service;

import java.util.List;



import com.cg.dao.CustomerDAO;
import com.cg.dao.ICustomerDAO;
import com.cg.exception.CustomerException;
import com.cg.userbean.Customer;


public class CustomerServiceImpl implements ICustomerService{
	private ICustomerDAO dao = null;


	public CustomerServiceImpl() {
		dao = new CustomerDAO();
	}


	@Override
	public int add(Customer e) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.add(e);
	}


	@Override
	public List<Customer> getAll() throws CustomerException {
		// TODO Auto-generated method stub
		return dao.getAll();
	}


	@Override
	public String register(Customer user) {
		// TODO Auto-generated method stub
		return null;
	}


	
		
	}
	










