package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;

import com.cg.exception.CustomerException;


import com.cg.userbean.Customer;
import com.cg.util.DBUtil;

public class CustomerDAO implements ICustomerDAO{
	
	private static final String INSERT_QUERY
	="INSERT into users(name,user_name,password,mobile_number) "+  
		"   values(seq_bills.nextval, ?,?,?,?)";
	
	
	private static final String GET_ALL_QUERY
	="select name,user_name,password,mobile_number from users";
	
	private static final String UPDATE_QUERY
	= "update users set name=?, user_name=?, "
	+ "  password=?, phone=?, email=? where empid=?";

private static final String SELECT_QUERY=
			"select empid,ename,gender,designation,phone,email from emp12 where empid=?";

	

	
	
	@Override
	public int add(Customer e) throws CustomerException {
		try{
			Connection con = DBUtil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setString(1,e.getName());
			ps.setString(2, e.getPhone());
			ps.setString(3,e.getUname());
			ps.setString(4,e.getPassword());
			ps.setString(5, e.getRepassword());
			ps.executeUpdate();
			int id =0;
			//Get generated Primary key:
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select seq_bills.currval from dual");
			if(rs.next()){				
				id = rs.getInt(1);
				System.out.println("SEQ value "+id);
			}
			con.close();
			return id;
		}catch(NamingException | SQLException ex){
			throw new CustomerException("Unable to save, "+ex.getMessage());
		}
	}






	@Override
	public List<Customer> getAll() throws CustomerException {
		// TODO Auto-generated method stub
		
		try{
			Connection con = DBUtil.obtainConnection();
			PreparedStatement ps = con.prepareStatement(GET_ALL_QUERY);
			ResultSet rs = ps.executeQuery();
			//Create EMPTY list
			List<Customer> cmps = new LinkedList<>();
			//Get ONE record at a time
			while(rs.next()){
				Customer e = new Customer();
				//Store ALL values into Employee Object
				//"e" is now D.T.O.
				e.setName(rs.getString(1));
				e.setPhone(rs.getString(2));
				e.setUname(rs.getString(3));
				e.setPassword(rs.getString(4));
				e.setRepassword(rs.getString(5));
				//Add DTO into LIST
				cmps.add(e);
			}
			con.close();
			//return LIST
			return cmps;
		}catch(NamingException | SQLException ex){
			throw new CustomerException("Unable to fetch records, "+ex.getMessage());
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}

	
	
	
	
	
}
