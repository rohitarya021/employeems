package com.cg.dao;

import java.util.List;


import com.cg.exception.CustomerException;



import com.cg.userbean.Customer;

public interface ICustomerDAO {
	
	int add(Customer e) throws CustomerException;

	List<Customer> getAll() throws CustomerException;
	
}

