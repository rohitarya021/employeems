package com.cg.userbean;

import java.io.Serializable;

public class Customer implements Serializable 
{

	
	private String name;
	private String phone;
	private String uname;
	private String password;
	private String repassword;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRepassword() {
		return repassword;
	}
	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", phone=" + phone + ", uname="
				+ uname + ", password=" + password + ", repassword="
				+ repassword + "]";
	}
	public Customer(String name, String phone, String uname, String password,
			String repassword) {
		super();
		this.name = name;
		this.phone = phone;
		this.uname = uname;
		this.password = password;
		this.repassword = repassword;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
	
	
	
}
