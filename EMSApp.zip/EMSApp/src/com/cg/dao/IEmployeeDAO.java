package com.cg.dao;

import java.util.List;

import com.cg.exception.EmployeeException;

import com.cg.models.Employee;

public interface IEmployeeDAO {
	
	int add(Employee e) throws EmployeeException;
	
	List<Employee> getAll() throws EmployeeException;
	
	void update(Employee e) throws EmployeeException;

	Employee search(int empId)throws EmployeeException;
}