package com.cg.service;

import java.util.List;

import com.cg.dao.EmployeeDAO;
import com.cg.dao.IEmployeeDAO;
import com.cg.exception.EmployeeException;
import com.cg.models.Employee;

public class EmployeeServiceImpl implements IEmployeeService {
private IEmployeeDAO dao = null;

	public EmployeeServiceImpl() {
		dao = new EmployeeDAO();
	}
	
	@Override
	public int add(Employee e) throws EmployeeException {
		return dao.add(e);
	}

	@Override
	public List<Employee> getAll() throws EmployeeException {
		return dao.getAll();
	}

	@Override
	public void update(Employee e)throws EmployeeException {
		dao.update(e);
	}
	
	@Override
		public Employee search(int empid) throws EmployeeException {
			return dao.search(empid);
		}

}