package com.cg.springmvctwo.dao;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface IMobileDao {
	List<Mobile> showData();
	
	void removeMobile(int mobileId);
	void updateMobile(Mobile mob);
	Mobile searchMobile(int mobileId);

}
