package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;
@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{
	
	@PersistenceContext
	EntityManager EntityManager ;
	

	@Override
	public List<Mobile> showData() {
	
	Query querOne = EntityManager.createQuery("From Mobile");
	List<Mobile> mobList = querOne.getResultList();
	System.out.println(mobList);
		return mobList;
	}


	@Override
	public void removeMobile(int mobileId) {
		Query queryTwo = EntityManager.createQuery("DELETE FROM Mobile where mobileId = :mobile_id");
		queryTwo.setParameter("mobile_id", mobileId);
		queryTwo.executeUpdate();
	
		
	}


	@Override
	public void updateMobile(Mobile mob) {
		Query queryTwo = EntityManager.createQuery("Update Mobile SET mobileName = :mob_name , mobilePrice = :mob_price , mobileBrand = :mob_brand where mobileId = :mob_id");
	    queryTwo.setParameter("mob_id", mob.getMobileId());
	    queryTwo.setParameter("mob_name", mob.getMobileName());
	    queryTwo.setParameter("mob_brand", mob.getMobileBrand());
	    queryTwo.setParameter("mob_price", mob.getMobilePrice());
	    queryTwo.executeUpdate();
	    
	
	}


	@Override
	public Mobile searchMobile(int mobileId) {
		Query querOne = EntityManager.createQuery("From Mobile where mobileId = :mobile_id");
		querOne.setParameter("mobile_id", mobileId);
		Mobile mobList =(Mobile)querOne.getSingleResult();
		System.out.println(mobList);
			return mobList;
	}

}
