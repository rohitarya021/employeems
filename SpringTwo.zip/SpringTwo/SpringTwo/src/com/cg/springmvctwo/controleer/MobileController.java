package com.cg.springmvctwo.controleer;

import java.util.List;
import java.util.Map;

import org.jboss.resteasy.spi.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvctwo.dto.Mobile;
import com.cg.springmvctwo.service.IMobileService;


@Controller
public class MobileController {
	
	@Autowired
	IMobileService mobileservice;
	

	@RequestMapping(value = "show" , method = RequestMethod.GET  )
	public ModelAndView show()
	{
		List<Mobile> mobList =  mobileservice.showData();
		System.out.println(mobList);
		
		return new ModelAndView("list", "mobList", mobList);
	}
	
	@RequestMapping(value = "delete" , method =RequestMethod.GET)
	public String deleteData(@RequestParam("id") int id)
	{
		System.out.println(id);
		mobileservice.removeMobile(id);
		List<Mobile> mobList = mobileservice.showData();
		
		return "redirect:/show";
	}
	
	
	@RequestMapping(value  = "update" , method = RequestMethod.GET )
	public String update(@RequestParam("id") int id ,Map<String,Object> model , @ModelAttribute("my")Mobile mob)
	{
		
		 mob = mobileservice.searchMobile(id);
		
		System.out.println("In controller "+mob);
		model.put("my",mob);
		return "updateList";
		
	}
	
	@RequestMapping(value = "putdata" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("my")Mobile mob)
	{
		mobileservice.updateMobile(mob);
		return "redirect:/show";
		
	}
}
