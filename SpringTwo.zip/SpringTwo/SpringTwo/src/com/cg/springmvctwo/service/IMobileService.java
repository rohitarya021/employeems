package com.cg.springmvctwo.service;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface IMobileService {
	
	List<Mobile> showData();
	void removeMobile(int mobileId);
	void updateMobile(Mobile mob);
	Mobile searchMobile(int MobileId);

}
